import { base44 } from './base44Client';


export const aiTrainer = base44.functions.aiTrainer;

export const generateInitialExercises = base44.functions.generateInitialExercises;

export const getMotivationalQuote = base44.functions.getMotivationalQuote;

export const validateWorkout = base44.functions.validateWorkout;

